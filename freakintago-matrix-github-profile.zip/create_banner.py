from PIL import Image, ImageDraw, ImageFont
import random

W, H, N = 1200, 320, 32
font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
try:
    font = ImageFont.truetype(font_path, 15)
    title_font = ImageFont.truetype(font_path, 39)
    sub_font = ImageFont.truetype(font_path, 17)
    small_font = ImageFont.truetype(font_path, 13)
except OSError:
    font = title_font = sub_font = small_font = ImageFont.load_default()

random.seed(42)
cols = list(range(8, W-8, 18))
streams = [random.randint(-H, H) for _ in cols]
speeds = [random.randint(5, 12) for _ in cols]
frames = []
for f in range(N):
    im = Image.new("RGB", (W, H), (2, 7, 4))
    d = ImageDraw.Draw(im)
    for x in range(0, W, 60): d.line((x, 0, x, H), fill=(3, 20, 9))
    for y in range(0, H, 40): d.line((0, y, W, y), fill=(3, 18, 8))
    for i, x in enumerate(cols):
        y = (streams[i] + f * speeds[i]) % (H + 90)
        for trail in range(9):
            yy = y - trail * 17
            if 0 <= yy < H:
                ch = random.choice("01ABCDEFGHIJKLMNOPQRSTUVWXYZ$#<>[]{}")
                if trail == 0: color = (210, 255, 220)
                else:
                    g = max(35, 245 - trail * 24)
                    color = (0, g, min(85, 15 + trail * 7))
                d.text((x, yy), ch, font=font, fill=color)
    d.rounded_rectangle((120,74,1080,242), radius=18, fill=(1,9,4), outline=(20,160,45), width=2)
    d.line((155,104,300,104), fill=(57,255,20), width=2)
    d.line((900,210,1045,210), fill=(57,255,20), width=2)
    d.text((W//2,119), "TAGALDEEN // CYBERSECURITY", font=title_font, fill=(57,255,20), anchor="mm")
    d.text((W//2,169), "> LEARN  •  BUILD  •  INVESTIGATE  •  SECURE _", font=sub_font, fill=(205,255,213), anchor="mm")
    d.text((W//2,211), "NETWORK SECURITY  |  LINUX  |  PROGRAMMING  |  CYBER DEFENSE", font=small_font, fill=(70,220,100), anchor="mm")
    frames.append(im)
frames[0].save("matrix-banner.gif", save_all=True, append_images=frames[1:], duration=100, loop=0, optimize=True)
print("Created matrix-banner.gif")
