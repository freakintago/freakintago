<div align="center">

<img src="./matrix-banner.gif" alt="Animated green Matrix cybersecurity banner" width="100%">

# `> whoami`

### TagAldeen Mohamed
**Cybersecurity Student · Aspiring Cybersecurity Engineer**

[![GitHub](https://img.shields.io/badge/GitHub-freakintago-39FF14?style=for-the-badge&logo=github&logoColor=black)](https://github.com/freakintago)
[![Focus](https://img.shields.io/badge/FOCUS-CYBERSECURITY-101510?style=for-the-badge&logo=hackthebox&logoColor=39FF14)](https://github.com/freakintago)
[![Learning](https://img.shields.io/badge/STATUS-BUILDING%20AND%20LEARNING-101510?style=for-the-badge&logo=linux&logoColor=39FF14)](https://github.com/freakintago)

**`LEARN` · `BUILD` · `INVESTIGATE` · `SECURE`**

</div>

---

## `01 // ABOUT ME`

Hello! I'm **TagAldeen**, a cybersecurity student at **KPR Institute of Engineering and Technology (KPRIET)**. I'm building practical skills in cybersecurity, networking, Linux, and software development through coursework, labs, and personal projects.

My goal is to become a capable cybersecurity engineer who can understand systems, investigate security issues, and help build more secure digital environments.

- 🛡️ **Career direction:** Cybersecurity Engineering
- 🔎 **Interests:** Network security, security analysis, and ethical hacking in authorized labs
- 🐧 **Systems:** Linux, Kali Linux fundamentals, and Windows
- 🌐 **Networking:** TCP/IP, DNS, routing, switching, and packet analysis
- 💻 **Programming:** Java, C, and Python fundamentals
- 🚀 **Current project:** CyberSafe — URL Safety Checker
- 📚 **Working style:** Learn the concept, test it safely, document results, improve

> I aim to demonstrate skills through working projects and clear technical documentation—not just a list of tools.

## `02 // TECHNOLOGY STACK`

<div align="center">

### Security & Networking
<img src="https://img.shields.io/badge/Linux-111111?style=for-the-badge&logo=linux&logoColor=FCC624" alt="Linux">
<img src="https://img.shields.io/badge/Kali_Linux-111111?style=for-the-badge&logo=kalilinux&logoColor=557C94" alt="Kali Linux">
<img src="https://img.shields.io/badge/Wireshark-111111?style=for-the-badge&logo=wireshark&logoColor=1679A7" alt="Wireshark">
<img src="https://img.shields.io/badge/Cisco-111111?style=for-the-badge&logo=cisco&logoColor=49B4E8" alt="Cisco">
<img src="https://img.shields.io/badge/VirtualBox-111111?style=for-the-badge&logo=virtualbox&logoColor=183A61" alt="VirtualBox">

### Programming Languages
<img src="https://img.shields.io/badge/Java-111111?style=for-the-badge&logo=openjdk&logoColor=ED8B00" alt="Java">
<img src="https://img.shields.io/badge/C-111111?style=for-the-badge&logo=c&logoColor=A8B9CC" alt="C">
<img src="https://img.shields.io/badge/Python-111111?style=for-the-badge&logo=python&logoColor=3776AB" alt="Python">
<img src="https://img.shields.io/badge/Bash-111111?style=for-the-badge&logo=gnubash&logoColor=4EAA25" alt="Bash">
<img src="https://img.shields.io/badge/HTML5-111111?style=for-the-badge&logo=html5&logoColor=E34F26" alt="HTML5">
<img src="https://img.shields.io/badge/CSS3-111111?style=for-the-badge&logo=css3&logoColor=1572B6" alt="CSS3">

### Developer Tools
<img src="https://img.shields.io/badge/Git-111111?style=for-the-badge&logo=git&logoColor=F05032" alt="Git">
<img src="https://img.shields.io/badge/GitHub-111111?style=for-the-badge&logo=github&logoColor=FFFFFF" alt="GitHub">
<img src="https://img.shields.io/badge/VS_Code-111111?style=for-the-badge&logo=visualstudiocode&logoColor=007ACC" alt="VS Code">
<img src="https://img.shields.io/badge/Packet_Tracer-111111?style=for-the-badge&logo=cisco&logoColor=49B4E8" alt="Packet Tracer">

</div>

*These badges indicate technologies I am learning or using at a foundational level; they do not imply expert proficiency.*

## `03 // FEATURED PROJECT`

### 🛡️ CyberSafe — URL Safety Checker

A personal project intended to help users spot potentially suspicious URLs by checking URL characteristics and explaining warning signs.

**Planned / implemented features — keep only those that exist in the code:**
- URL input and validation
- Checks for suspicious URL patterns
- Explanations of potential warning indicators
- Test cases for different URL examples
- Documentation of limitations and false-positive risks

**Technology:** `Add the actual language and libraries here`

**Repository:** [Open my GitHub repositories](https://github.com/freakintago?tab=repositories)

**Security note:** A URL checker is a screening aid, not a guarantee that a site is safe or malicious. Do not open suspicious links automatically.

## `04 // OTHER WORK`

### 🌐 Networking & Routing Labs
Practice with network topologies, IP addressing, routing configuration, and connectivity tests using Cisco Packet Tracer.

### ☕ Java Programming
Practice with object-oriented programming, collections, exception handling, file operations, and multithreading.

### 🧩 Data Structures & Algorithms
Practice with linked lists, stacks, queues, trees, graphs, BFS, DFS, Dijkstra, and Prim.

*Add direct repository links and screenshots when the work is published.*

## `05 // CURRENT ROADMAP`

- [ ] Improve Linux administration and network troubleshooting
- [ ] Document Wireshark packet-analysis labs
- [ ] Improve CyberSafe logic and automated tests
- [ ] Learn security logs, alert triage, and SOC workflows
- [ ] Build a safe, authorized cybersecurity lab
- [ ] Practice incident analysis and technical report writing
- [ ] Develop Python scripts for security-related tasks
- [ ] Publish reproducible projects with setup instructions and evidence

## `06 // GITHUB ACTIVITY`

<div align="center">

<img height="165" src="https://github-readme-stats.vercel.app/api?username=freakintago&show_icons=true&hide_border=true&bg_color=080B0A&title_color=39FF14&icon_color=39FF14&text_color=D7F5DD" alt="GitHub statistics">

<img height="165" src="https://github-readme-stats.vercel.app/api/top-langs/?username=freakintago&layout=compact&hide_border=true&bg_color=080B0A&title_color=39FF14&text_color=D7F5DD" alt="Most used languages">

[![GitHub Streak](https://streak-stats.demolab.com?user=freakintago&hide_border=true&background=080B0A&ring=39FF14&fire=39FF14&currStreakLabel=39FF14&sideLabels=D7F5DD&dates=8BAA91)](https://github.com/freakintago)

</div>

*Stats are provided by third-party services and may occasionally be unavailable. Language statistics do not measure proficiency.*

## `07 // CONNECT`

- **GitHub:** [@freakintago](https://github.com/freakintago)
- **LinkedIn:** `Add your LinkedIn profile URL`
- **Email:** `Add a professional contact email`

<div align="center">

### `> ACCESS GRANTED: KEEP LEARNING`

**Thanks for visiting. Let's build a safer digital world.** 🟢

</div>
